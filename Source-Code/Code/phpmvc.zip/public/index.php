<?php

require '../app/start.php';

$app = new App;